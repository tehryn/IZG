var searchData=
[
  ['phongvariables',['PhongVariables',['../structPhongVariables.html',1,'']]]
];
