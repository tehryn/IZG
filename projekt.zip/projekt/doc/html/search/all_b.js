var searchData=
[
  ['near',['NEAR',['../student__pipeline_8h.html#ae9e1c8a3d097c4fa8df79abc03911ec5a428074548efef09696dcc7eaff3d195b',1,'student_pipeline.h']]],
  ['noftriangles',['nofTriangles',['../structGPUTriangleList.html#a8bab6c6758e097060186e69fa1560494',1,'GPUTriangleList']]],
  ['nofusedvertices',['nofUsedVertices',['../structGPUPrimitive.html#aaeea5342673689813c4aff110677d403',1,'GPUPrimitive']]],
  ['noperspective',['NOPERSPECTIVE',['../program_8h.html#a8472f01c511d77bbfb981a46618ea1eaacdc92eb62e3be278780c22beb101971c',1,'program.h']]],
  ['normal',['normal',['../structBunnyVertex.html#aa7f67904a835c896f368dd2e37cc46db',1,'BunnyVertex']]],
  ['normalize_5fvec2',['normalize_Vec2',['../linearAlgebra_8c.html#aef887725c2f4d11256731400b232a1bf',1,'normalize_Vec2(Vec2 *const output, Vec2 const *const input):&#160;linearAlgebra.c'],['../linearAlgebra_8h.html#aef887725c2f4d11256731400b232a1bf',1,'normalize_Vec2(Vec2 *const output, Vec2 const *const input):&#160;linearAlgebra.c']]],
  ['normalize_5fvec3',['normalize_Vec3',['../linearAlgebra_8c.html#a29413d309c1692fac4d63a4fc080903c',1,'normalize_Vec3(Vec3 *const output, Vec3 const *const input):&#160;linearAlgebra.c'],['../linearAlgebra_8h.html#a29413d309c1692fac4d63a4fc080903c',1,'normalize_Vec3(Vec3 *const output, Vec3 const *const input):&#160;linearAlgebra.c']]],
  ['normalize_5fvec4',['normalize_Vec4',['../linearAlgebra_8c.html#a8333ef95a3ea4503121bd0f8ec2e5a93',1,'normalize_Vec4(Vec4 *const output, Vec4 const *const input):&#160;linearAlgebra.c'],['../linearAlgebra_8h.html#a8333ef95a3ea4503121bd0f8ec2e5a93',1,'normalize_Vec4(Vec4 *const output, Vec4 const *const input):&#160;linearAlgebra.c']]]
];
