var searchData=
[
  ['vertices_5fper_5ftriangle',['VERTICES_PER_TRIANGLE',['../fwd_8h.html#a67df0e09b776eea53360bcc8f4a82ac9',1,'fwd.h']]]
];
