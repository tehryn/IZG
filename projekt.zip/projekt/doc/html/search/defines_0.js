var searchData=
[
  ['activate_5fdnn',['ACTIVATE_DNN',['../fwd_8h.html#a7764137b84ba622bda0e490c60517063',1,'fwd.h']]]
];
