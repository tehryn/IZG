var searchData=
[
  ['channels_5fper_5fcolor',['CHANNELS_PER_COLOR',['../fwd_8h.html#ae0962add35b8ccd089f9cc2cbc690d2f',1,'fwd.h']]]
];
